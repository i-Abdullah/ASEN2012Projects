function [ derivatives ] = RocketODE 
%
%
%
%
%
%
% --------- (States In order)------------------
% 1- Mass of rocket;
% 2- Masso of Air
% 3- Volume;
% 4- Velocity x;
% 5- Velocity z;
% 6- Range (X location);
% 7- Height (Z location);
% 

% PREDEFINE Constants:


%% Phase 1: 
if i=1

PressurePhase1 = ( ( V0 ./ States(1) ) .^ Gamma ) .* (Pgage+Pamb) ; 
ThrustPhase1 = 2.*cd.* At .* ( PressurePhase1 - Pamb) ;
TotalVeloc = sqrt( (States(3).^2) + (States(4).^2) );
DragPhase1 = ( RohAirBoulder / 2) .* (TotalVeloc).^2 * CD*Ab; 


%% Phase 2: 
elseif i=2
s
s
s

    
    
%% Phase 3: 

else
    
end


end